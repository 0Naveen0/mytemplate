<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
Contact>>>>

<br/><br/><br/><br/><br/>
Contact us........
<br/><br/><br/>
Proprietor<br/>
<address>
Anil Kumar<br/>
Rambagh<br/>
Darbhanga,Bihar<br/>
Email:&nbsp;apoorva.traders2011@gmail.com<br/>
contact:&nbsp;+91-7766909446<br/>
</address>

<div class="mapouter">
    <div class="gmap_canvas">
        <iframe width="600" height="450" id="gmap_canvas" src="https://maps.google.com/maps?q=apoorva%20traders%20piaggio%20ape%20showroom%20darbhanga&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0">
            
        </iframe>
        </div>
        </div>
