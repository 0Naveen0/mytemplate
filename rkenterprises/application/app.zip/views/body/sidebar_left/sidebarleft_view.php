<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
echo '<div class="row">
<div class="col-sm-1">&nbsp;</div>
<div class="col-sm-10">
<div class="row">
    <div class="col-sm-12">
        <img class="img-responsive" src="'. base_url().'assets/images/Apoorva/Bajajlogo.png" alt="Bajaj Logo" />
    </div>
</div>
<div class="row">
    <div class="col-sm-12">
        <img class="img-responsive" src="'.base_url().'assets/images/Apoorva/johndeerelogo.jpg" alt="John Deere Logo" />
    </div>
</div>
<div class="row">
    <div class="col-sm-12">
        <img class="img-responsive" src="'.base_url().'assets/images/Apoorva/Supremelogo.png" alt="Bajaj Logo" />
    </div>
</div>
</div>
<div class="col-sm-1">&nbsp;</div>
</div>';

?>
