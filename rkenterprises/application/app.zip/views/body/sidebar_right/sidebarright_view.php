<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
echo '<div class="row">
<div class="row">
    <div class="col-sm-12">
        <img class="img-responsive" src="'. base_url().'assets/images/Apoorva/Bajajintracity.jpg" alt="Bajaj" />
    </div>
</div>
<div class="row">
    <div class="col-sm-12">
        <img class="img-responsive" src="'. base_url().'assets/images/Apoorva/JohnDeere.jpg" alt="John Deere" />
    </div>
</div>
<div class="row">
    <div class="col-sm-12">
        <img class="img-responsive" src="'.base_url().'assets/images/Apoorva/Supreme.jpeg" alt="supreme" />
    </div>
</div>
</div>';

?>
