<?php
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.nav-pills
 */
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!--
<ul class="nav nav-tabs nav-stacked affix" id="socialNav">
    
    <li><a class="img img-circle" href="http://www.twitter.com" target="_blank"><img src="/exameasy/assets/images/t.png" width="30" height="30"   alt="twitter"/></a>
    </li>
    <li><a class="img img-circle" href="http://www.youtube.com" target="_blank"><img src="/exameasy/assets/images/y.png" width="30" height="30"  alt="youtube"/></a>
    </li>
    <li><a class="img img-circle" href="http://www.facebook.com" target="_blank"><img src="/exameasy/assets/images/f.png" width="30" height="30"  alt="facebook"/></a>
    </li>
   <!--<li>﻿<a class="thumbnail" href="http://www.facebook.com" target="_blank"><img src="/easyexam/images/facebook1.jpg"  alt="facebook"/></a>
    </li>
</ul>
-->