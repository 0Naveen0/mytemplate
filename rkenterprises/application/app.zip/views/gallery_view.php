
<?php
defined('BASEPATH') OR exit('No direct script access allowed');


echo '<div class="row">
    <div class="row text-center"><div class="col-sm-12"><h2>Gallery</h2></div></div>
    <div class="row">
    <div class="col-sm-6"><img class="img-responsive" alt="" src="'. base_url().'assets/images/Apoorva/8.jpg" /></div>
    <div class="col-sm-6"><img alt="" class="img-responsive" src="'. base_url().'assets/images/Apoorva/9.jpg" /></div>
</div>
<div class="row">
    <div class="col-sm-6"><img class="img-responsive" alt="" src="'. base_url().'assets/images/Apoorva/10.jpg" /></div>
    <div class="col-sm-6"><img class="img-responsive" alt="" src="'. base_url().'assets/images/Apoorva/11.jpg" /></div>
</div>
<div class="row">
    <div class="col-sm-6"><img class="img-responsive" alt="" src="'. base_url().'assets/images/Apoorva/12.jpg" /></div>
    <div class="col-sm-6"><img class="img-responsive" alt="" src="'. base_url().'assets/images/Apoorva/5.jpg" /></div>
</div>
<div class="row">
    <div class="col-sm-6"><img alt="" class="img-responsive" src="'. base_url().'assets/images/Apoorva/6.jpg" /></div>
    <div class="col-sm-6"><img alt="" class="img-responsive" src="'. base_url().'assets/images/Apoorva/13.jpg" ></div>
</div>
<div class="row">
    <div class="col-sm-6"><img alt="" class="img-responsive" src="'. base_url().'assets/images/Apoorva/14.jpg" /></div>
    <div class="col-sm-6"><img alt="" class="img-responsive" src="'. base_url().'assets/images/Apoorva/15.jpg" /></div>
</div>
   
<div class="row">
    <div class="col-sm-6"><img alt="" class="img-responsive" src="'. base_url().'assets/images/Apoorva/16.jpg" /></div>
    <div class="col-sm-6"><img alt="" class="img-responsive" src="'. base_url().'assets/images/Apoorva/1.jpg" /></div>
</div></div>';


