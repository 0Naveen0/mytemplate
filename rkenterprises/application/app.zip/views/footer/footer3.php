<?php
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<strong>Useful Links</strong><br/>
<a href="http://www.piaggio.co.in/product.php/"target="_blank">Piaggio Vehicles PVT Limited</a><br/>
<a href="http://www.supreme.co.in/moulded-plastic-furniture.php"target="_blank">Supreme</a><br/>
<a href="https://www.deere.com/en/index.html"target="_blank">John Deere</a><br/>
<a href="http://samratsteel.ml" target="_blank">Samrat Steel</a><br/>
<a href="http://www.gmail.com"target="_blank">Gmail</a><br/>

<a href="http://www.google.co.in"target="_blank">Google</a><br/>
