<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<ul class="nav nav-tabs nav-tabs">

    <li><a class="img img-circle" href="http://www.twitter.com" target="_blank"><img src="/apoorvatraders/assets/images/t.png" width="30" height="30"   alt="twitter"/></a>
    </li>
    <li><a class="img img-circle" href="http://www.youtube.com" target="_blank"><img src="/apoorvatraders/assets/images/y.png" width="30" height="30"  alt="youtube"/></a>
    </li>
    <!--<li><a class="img img-circle" href="http://www.facebook.com" target="_blank"><img src="/apoorvatraders/assets/images/f.png" width="30" height="30"  alt="facebook"/></a>
    </li>-->
    <li>
        <iframe src="https://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fapoorvatraders.ml&width=450&layout=button&action=like&size=small&show_faces=true&share=true&height=80&appId" width="450" height="80" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
    </li>
    <li>
        <?php //echo 'Visitors&nbsp;:&nbsp;'.$this->count_visitor;?>
    </li>
</ul>