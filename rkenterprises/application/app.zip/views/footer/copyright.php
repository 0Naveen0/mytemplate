<?php
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div>
    <div class="col-sm-3"><?php echo 'Visitors&nbsp;:&nbsp;'.$this->count_visitor;?></div>
    <div class="col-sm-6 "><strong><small>Copyright&nbsp;&copy;&nbsp; Apoorva&nbsp;Traders- 2019,&nbsp;&nbsp;&nbsp;&nbsp; Developed by : naveenkamal.2011@gmail.com</small></strong></div>
    <div class="col-sm-3">Updated on:16-Feb-2019</div>
</div>

