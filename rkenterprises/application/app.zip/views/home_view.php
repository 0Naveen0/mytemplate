<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
 <p>
 <h1>Welcome To Apoorva Traders</h1>
        Apoorva Traders Darbhanga has been in the business of retailing and 
        distribution of furniture and automobile. We stocks and retails plastic furniture,three wheelers and tractors. 
        We also deals in office furnishings
        for commercial places and business houses.We are appointed as Piaggio Three Wheeler dealer as well as John Deere Tractor.We are in this business for many years,
        this enterprise is one of the prominent points-of-sale in the city for buying 
        fancy and stylish furniture pieces,three wheelers and tractors.Being 
        of high quality, trendy designs and available at affordable price points,
        the products have helped us gain a staggering base of customers over the
        course of time. For the local citizens of darbhanga , our organisation is a 
        recognised name. We occupies a prominent location at ,darbhanga , surrounded by 
        innumerous shopping destinations and commercial complexes. Rambagh,
        Banglagarh, Lalbagh acts as a landmark in locating this showroom. 
        
    </p>
    <hr/>
    
<caption><u>25 Lakhs Celebration Media Coverage</u></caption>
<iframe width="90%" height="315" src="https://www.youtube.com/embed/pYm1wbjsv8U" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<!--<video   height="450" width="90%" controls>
    <source src="https://drive.google.com/uc?export=download&id=1Hn2Jcjy5LZrRB6hwMfyRe5uC0HrG-qVK " type='video/mp4'>
    This browser is unable to play this video. 
</video>-->
	
	

	


