<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.nav-pills
 */
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<ul class=" nav-pills nav  navbar-right">
    <li><a class="btn btn-block" href="<?php echo base_url().'index.php/home/login';?>" ><span class="glyphicon glyphicon-log-in"></span> Log In</a></li>
    <li><a class="btn btn-block" href="<?php echo base_url().'index.php/home/reg';?>" ><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
</ul>