<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
defined('BASEPATH') OR exit('No direct script access allowed');
//$examSelected = is_null($this->session->userdata('examid')) ? "" : ($this->session->userdata('examid'));
//$questionNo=isset($questionNumber)?$questionNumber:0;
//$questionNo =(is_null($currentQuestionNo)OR(!defined($currentQuestionNo)))?0:$currentQuestionNo;
?>
<?php 
//echo $message;
?>

    
            
           
            <h2 class='text-center '>Customer Account Summary</h2>
            
            



    
                <div id=customerAccountSummaryForBranchContent name=customerAccountSummaryForBranchContent>
                    
                    <?php
                    echo $customerData;
                    
                    ?>
                </div>
    
    


