<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
defined('BASEPATH') OR exit('No direct script access allowed');
//$examSelected = is_null($this->session->userdata('examid')) ? "" : ($this->session->userdata('examid'));
//$questionNo=isset($questionNumber)?$questionNumber:0;
//$questionNo =(is_null($currentQuestionNo)OR(!defined($currentQuestionNo)))?0:$currentQuestionNo;
?>
<?php echo $message;?>
<div >
    <form role="form" class="form-horizontal small" method='post' id="addQuestionfrm">
        <fieldset>  
            
           
            <legend class='text-center '>Add Question</legend>
            
            <div class="form-group">
                <label for="qno" class="col-sm-3 control-label">Question No.</label>
                <div class="col-sm-9">

                    <input type="text" class="form-control" id="qno" name='qno' value="<?php echo $questionAdded; ?>"
                           required="required" readonly>
                </div>
            </div>


            <div class="form-group"> 
                <div class="">
                    <label for="qtext" class="control-label col-sm-3">Question</label>
                </div>
                <div class="col-sm-9 ">
                    <textarea class="form-control" id="qtext" name='qtext' maxlength="150" required="required"></textarea>

                </div>

            </div>
            <div class="form-group"> 

                <label  class="control-label col-sm-3">Type</label>
                <div class="col-sm-9">
                    <label class='checkbox-inline'>
                        <input type="radio" class="" name='qtype' id='mcqRadio' value='MCQ' checked >Multiple Choice
                    </label>
                    <label class='checkbox-inline'>
                        <input type="radio" class=" " name='qtype' id='trueFalseRadio' value='TF'  >True/False
                    </label>
                </div>
            </div>
            <div class="form-group">        
                <label for="optionAText" class="col-sm-3 control-label">Option A.</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control col-sm-9" id="optionAText" maxlength="50" name='optionAText' required="required"
                           >
                </div>
            </div>
            <div class="form-group">        
                <label for="optionBText" class="col-sm-3 control-label">Option B.</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" id="optionBText" maxlength="50" name='optionBText' required="required"
                           >
                </div>
            </div>
            <div class="form-group" id='optionCTextGroup'>        
                <label for="optionCText" class="col-sm-3 control-label">Option C.</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" id="optionCText" maxlength="50" name='optionCText' required="required"
                           >
                </div>
            </div>
            <div class="form-group" id='optionDTextGroup'>        
                <label for="optionDText" class="col-sm-3 control-label">Option D.</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" id="optionDText" maxlength="50" name='optionDText' required="required"
                           >
                </div>
            </div>

            <div class="form-group"> 

                <label  class="control-label col-sm-3">Select Answer</label>


                <div class="col-sm-9" >
                    <label class='checkbox-inline'>
                        <input type="radio" class="" name='selectAnswer' id='optionA' value='optionA'  >A
                    </label>      

                    <label class='checkbox-inline'>
                        <input type="radio" class=" " name='selectAnswer' id='optionB' value='optionB'  >B

                    </label>
                    <label class='checkbox-inline' id='labelOptionC'>
                        <input type="radio" class=" " name='selectAnswer' id='optionC' value='optionC'  >C

                    </label>
                    <label class='checkbox-inline' id='labelOptionD'>
                        <input type="radio" class=" " name='selectAnswer' id='optionD' value='optionD'  >D

                    </label>
                </div>
            </div>


            <div class="form-group">        
                <label for="answer" class="col-sm-3 control-label">Answer</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" id="answer" maxlength="50" name='answer' readonly required="required"
                           >
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-9">
                </div>
                <div class="col-sm-3">
                    <input type="reset" class="btn btn-default pull-right" name="resetBtn" value="Clear">
                    <button type='submit' class="btn btn-default " name="addQuestionBtn" value='add'>Add</button>&nbsp;
                    
                </div>
            </div>
        </fieldset>
    </form>
</div>

