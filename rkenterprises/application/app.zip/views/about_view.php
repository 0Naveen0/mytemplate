<?php
defined('BASEPATH') OR exit('No direct script access allowed');


echo "
<h4>About</h4>
    <p>
        Apoorva Traders Darbhanga has been in the business of retailing and 
        distribution of furniture and automobile. We stocks and retails plastic furniture,three wheelers and tractors. 
        We also deals in office furnishings
        for commercial places and business houses.We are appointed as Piaggio Three Wheeler dealer as well as John Deere Tractor.We are in this business for many years,
        this enterprise is one of the prominent points-of-sale in the city for buying 
        fancy and stylish furniture pieces,three wheelers and tractors.Being 
        of high quality, trendy designs and available at affordable price points,
        the products have helped us gain a staggering base of customers over the
        course of time. For the local citizens of darbhanga , our organisation is a 
        recognised name. We occupies a prominent location at ,darbhanga , surrounded by 
        innumerous shopping destinations and commercial complexes. Rambagh,
        Banglagarh, Lalbagh acts as a landmark in locating this showroom. 
        
    </p>

    <address>    	
<p>Furniture Section:</p>

	
	<p>Rambagh, Banglagarh </p>
	
		
<p>Darbhanga, Bihar</p>
<p>Contact: 9939726773</p>
<p>Contact Person:&nbsp;Mr.&nbsp;Amit&nbsp;Kumar</p>
<p><email>Email:-apoorva.traders2011@gmail.com</email></p>
    </address>
     <address>    	
<p>Automobile Section:</p>

	
	<p>Mabbi Belauna </p>
	
		
<p>Darbhanga, Bihar</p>
<p>Contact: 7766909446</p>
<p>Contact Person:&nbsp;Mr.&nbsp;Anil&nbsp;Kumar</p>
<p><email>Email:-apoorva.traders2011@gmail.com</email></p>
    </address>
	






";


   