<?php

defined('BASEPATH') OR exit('No direct script access allowed');

?>
<div class="row">
        <div class="col-sm-12 text-center">
            <h2>John Deere</h2>
        </div>
       
    </div>

<div class="panel-group" id="accordion">
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">
        5045 D</a>
      </h4>
    </div>
    <div id="collapse1" class="panel-collapse collapse in">
      <div class="panel-body">
          
          <div class="row">
        <div class="col-sm-12 ">
         <a href="<?php echo base_url().'assets/images/company2/1.jpg';?>" target="_blank">  <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/1.jpg';?>" alt="Tractor image"/>
         </a>
        </div>
        </div>
        
         <div class="row">
        <div class="col-sm-12 text-center">
           &nbsp;
        </div>
        
         <div class="row">
        <div class="col-sm-12 ">
            <a href="<?php echo base_url().'assets/images/company2/1s.jpg';?>" target="_blank"> 
            <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/1s.jpg';?>" alt="Tractor specification"/>
            </a>
        </div>
    </div>
          
      </div>
      
      
    </div>
  </div>
  </div>
  
  
  
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">
       5036 D</a>
      </h4>
    </div>
    <div id="collapse2" class="panel-collapse collapse">
      <div class="panel-body">
          
      
      <div class="row">
        <div class="col-sm-12 ">
         <a href="<?php echo base_url().'assets/images/company2/2.jpg';?>" target="_blank">  <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/2.jpg';?>" alt="Tractor image"/>
         </a>
        </div>
        </div>
        
         <div class="row">
        <div class="col-sm-12 text-center">
           &nbsp;
        </div>
        </div>
        
         <div class="row">
        <div class="col-sm-12 ">
            <a href="<?php echo base_url().'assets/images/company2/2s.jpg';?>" target="_blank"> 
            <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/2s.jpg';?>" alt="Tractor specification"/>
            </a>
        </div>
    </div>
         
      
      
      
      
      
    
    
    
    
    
    
    
    
    
    
    
      </div>
    </div>
  </div>
  
  
  <!--panel3 start-->
  
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">
        5055 E</a>
      </h4>
    </div>
    <div id="collapse3" class="panel-collapse collapse">
      <div class="panel-body">
         
           <div class="row">
        <div class="col-sm-12 ">
         <a href="<?php echo base_url().'assets/images/company2/3.jpg';?>" target="_blank">  <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/3.jpg';?>" alt="Tractor image"/>
         </a>
        </div>
        </div>
        
         <div class="row">
        <div class="col-sm-12 text-center">
           &nbsp;
        </div>
        </div>
        
         <div class="row">
        <div class="col-sm-12 ">
            <a href="<?php echo base_url().'assets/images/company2/3s.jpg';?>" target="_blank"> 
            <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/3s.jpg';?>" alt="Tractor specification"/>
            </a>
        </div>
    </div>
         
      
      
      </div>
    </div>
  </div>
  
  <!-- Panel3 End-->
  
  
  
  
</div>
































<!--














<div>
    <div class="row">
        <div class="col-sm-12 text-center">
            <h2>John Deere</h2>
        </div>
       
    </div>
    
    <div class="row">
        <div class="col-sm-6 ">
         <a href="<?php echo base_url().'assets/images/company2/1.jpg';?>" target="_blank">  <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/1.jpg';?>" alt="Tractor image"/>
         </a>
        </div>
        <div class="col-sm-6 ">
            <a href="<?php echo base_url().'assets/images/company2/1s.jpg';?>" target="_blank"> 
            <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/1s.jpg';?>" alt="Tractor specification"/>
            </a>
        </div>
    </div>
    
     <div class="row">
        <div class="col-sm-12 text-center">
           &nbsp;
        </div>
       
    </div>
    
     <div class="row">
        <div class="col-sm-6 ">
            <a href="<?php echo base_url().'assets/images/company2/2.jpg';?>" target="_blank"> 
            <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/2.jpg';?>" alt="Tractor image"/>
            </a>
        </div>
        <div class="col-sm-6 ">
            <a href="<?php echo base_url().'assets/images/company2/2s.jpg';?>" target="_blank"> 
            <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/2s.jpg';?>" alt="Tractor specification"/>
            </a>
        </div>
    </div>
    
     <div class="row">
        <div class="col-sm-12 text-center">
           &nbsp;
        </div>
       
    </div>
    
     <div class="row">
         <div class="col-sm-6 ">
             <a href="<?php echo base_url().'assets/images/company2/3.jpg';?>" target="_blank"> 
             <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/3.jpg';?>" alt="Tractor image"/>
             </a>
        </div>
        
        <div class="col-sm-6 ">
            <a href="<?php echo base_url().'assets/images/company2/3s.jpg';?>" target="_blank"> 
            <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/3s.jpg';?>" alt="Tractor specification"/>
            </a>
        </div>
    </div>
    
     <div class="row">
        <div class="col-sm-12 text-center">
           &nbsp;
        </div>
       
    </div>
    
     <div class="row">
        <div class="col-sm-6 ">
            <a href="<?php echo base_url().'assets/images/company2/4.jpg';?>" target="_blank"> 
            <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/4.jpg';?>" alt="Tractor image"/>
            </a>
        </div>
        <div class="col-sm-6 ">
            <a href="<?php echo base_url().'assets/images/company2/4s.jpg';?>" target="_blank"> 
            <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/4s.jpg';?>" alt="Tractor specification"/>
            </a>
        </div>
    </div>
    
     <div class="row">
        <div class="col-sm-12 text-center">
           &nbsp;
        </div>
       
    </div>
    
    
     <div class="row">
        <div class="col-sm-6 ">
            <a href="<?php echo base_url().'assets/images/company2/5.jpg';?>" target="_blank"> 
            <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/5.jpg';?>" alt="Tractor image"/>
            </a>
        </div>
        <div class="col-sm-6 ">
            <a href="<?php echo base_url().'assets/images/company2/5s.jpg';?>" target="_blank"> 
            <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/5s.jpg';?>" alt="Tractor specification"/>
            </a>
        </div>
    </div>
    
     <div class="row">
        <div class="col-sm-12 text-center">
           &nbsp;
        </div>
       
    </div>
    
    
     <div class="row">
         <div class="col-sm-6 ">
             <a href="<?php echo base_url().'assets/images/company2/6.jpg';?>" target="_blank"> 
             <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/6.jpg';?>" alt="Tractor image"/>
             </a>
        </div>
        <div class="col-sm-6 ">
            <a href="<?php echo base_url().'assets/images/company2/6s.jpg';?>" target="_blank"> 
            <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/6s.jpg';?>" alt="Tractor specification"/>
            </a>
            </div>
    </div>
    
     <div class="row">
        <div class="col-sm-12 text-center">
           &nbsp;
        </div>
       
    </div>
    
    
     <div class="row">
         <div class="col-sm-6 ">
             <a href="<?php echo base_url().'assets/images/company2/7.jpg';?>" target="_blank"> 
             <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/7.jpg';?>" alt="Tractor image"/>
             </a>
            </div>
        <div class="col-sm-6 ">
            <a href="<?php echo base_url().'assets/images/company2/7s.jpg';?>" target="_blank"> 
            <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/7s.jpg';?>" alt="Tractor specification"/>
            </a>
        </div>
    </div>
    
     <div class="row">
        <div class="col-sm-12 text-center">
           &nbsp;
        </div>
       
    </div>
    
    
     <div class="row">
       <div class="col-sm-6 ">
           <a href="<?php echo base_url().'assets/images/company2/8.jpg';?>" target="_blank"> 
           <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/8.jpg';?>" alt="Tractor image"/>
           </a>
        </div>
        <div class="col-sm-6 ">
            <a href="<?php echo base_url().'assets/images/company2/8s.jpg';?>" target="_blank"> 
            <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/8s.jpg';?>" alt="Tractor specification"/>
            </a>
        </div>
    </div>
    
     <div class="row">
        <div class="col-sm-12 text-center">
           &nbsp;
        </div>
       
    </div>
    
    
     <div class="row">
         <div class="col-sm-6 ">
             <a href="<?php echo base_url().'assets/images/company2/9.jpg';?>" target="_blank"> 
             <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/9.jpg';?>" alt="Tractor image"/>
             </a>
        </div>
        <div class="col-sm-6 ">
            <a href="<?php echo base_url().'assets/images/company2/9s.jpg';?>" target="_blank"> 
            <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/9s.jpg';?>" alt="Tractor specification"/>
            </a>
        </div>
    </div>
    
     <div class="row">
        <div class="col-sm-12 text-center">
           &nbsp;
        </div>
       
    </div>
    
    
     <div class="row">
        <div class="col-sm-6 ">
            <a href="<?php echo base_url().'assets/images/company2/10.jpg';?>" target="_blank"> 
            <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/10.jpg';?>" alt="Tractor image"/>
            </a>
        </div>
        <div class="col-sm-6 ">
            <a href="<?php echo base_url().'assets/images/company2/10s.jpg';?>" target="_blank"> 
            <img class="img img-responsive" src="<?php echo base_url().'assets/images/company2/10s.jpg';?>" alt="Tractor specification"/>
            </a>
        </div>
    </div>
    
    
</div>

-->