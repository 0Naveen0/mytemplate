<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div id="createExamfrm">
    <form role="form" class="form-horizontal small" method='post'>
        <fieldset>  
            <legend class='text-center '>Create Exam</legend>
            <div class="form-group">
                <label for="examname" class="col-sm-3 control-label">Exam Name</label>
                <div class="col-sm-9">

                    <input type="text" class="form-control" id="examname" name='examname'
                           placeholder="Enter Exam Name" required="required">
                </div>
            </div>
            <div class="form-group">       
                <label for="subject" class="col-sm-3 control-label">Subject</label>
                <div class="col-sm-9">      
                    <select class="form-control" name="subject">
                        <?php
                        $i = 0;
                        foreach ($subjectList as $subject) {
                            //echo $subject." </br>";
                            if ($i === 0) {
                                echo '<option value="' . $subject . '"  selected>' . $subject . '</option>';
                                $i = 1;
                            } else {
                                echo '<option value="' . $subject . '">' . $subject . '</option>';
                            }
                        }
                        ?>
                    </select>
                </div>     

            </div>

            <div class="form-group"> 
                <div class="">
                    <label for="dob" class="control-label col-sm-3">Exam Date</label>
                </div>
                <div class="col-sm-9  datetimepicker" id="datepicker">
                    <input type="date" class="form-control" id="examDate" name='examDate' required="required"/>
                </div>

            </div>

            <div class="form-group">        
                <label for="number_of_question" class="col-sm-3 control-label">Number of Question</label>
                <div class="col-sm-9">
                    <input type="number" class="form-control" id="number_of_question" min='10' max='250' name='number_of_question' required="required"
                           >
                </div>
            </div>

            <div class="form-group">        
                <label for="duration" class="col-sm-3 control-label">Duration(in minutes)</label>
                <div class="col-sm-9">
                    <input type="number" class="form-control" id="duration" min='5' max='180' name='duration' required="required"
                           >
                </div>
            </div>

            <div class="form-group">        
                <label for="marks_per_question" class="col-sm-3 control-label">Marks Per Question</label>
                <div class="col-sm-9">
                    <input type="number" class="form-control" id="marks_per_question" min='1' max='25' name='marks_per_question' required="required"
                           >
                </div>
            </div>

            <div class="form-group">        
                <label for="pass" class="col-sm-3 control-label">Passing Percent</label>
                <div class="col-sm-9">
                    <input type="number" class="form-control" id="pass" min='1' max='100' name='pass' required="required"
                           >
                </div>
            </div>
            <div class="form-group"> 

                <label  class="control-label col-sm-3">Negative Marking</label>
                <div class="col-sm-9">
                    <label class='checkbox-inline'>
                        <input type="radio" class="" name='negative' id='negativeTrueRadio' value='True'  >True
                    </label>
                    <label class='checkbox-inline'>
                        <input type="radio" class=" " name='negative' id='negativeFalseRadio' value='False' checked >False
                    </label>
                </div>
            </div>

            <div class="form-group">
                 <div class="col-sm-9">
                 </div>
                <div class="col-sm-3">

                    <input type="reset" class="btn btn-default pull-right" name="resetBtn" value="Clear">
                    <input type="submit" class="btn btn-default " name="createExamBtn" value="Create">&nbsp;
                </div>
            </div>

        </fieldset>
    </form>
</div>

